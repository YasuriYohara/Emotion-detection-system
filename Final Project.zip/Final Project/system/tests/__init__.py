# Tests package initialization
